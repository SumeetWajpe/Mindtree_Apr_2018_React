export default function posts(defStore=[],action){
   
    switch(action.type){


        case 'FETCH_POSTS': 
            // Update the Store !          
            defStore = action.response;
            return  defStore;       
        case 'INCREMENT_LIKES':
            
        var index = action.index;

        // change the store !

        return[
...defStore.slice(0,index),
{...defStore[index],likes:defStore[index].likes + 1},
...defStore.slice(index + 1)
        ]; // mutated store !            
         
            default:
            return defStore;
    }   
    
}