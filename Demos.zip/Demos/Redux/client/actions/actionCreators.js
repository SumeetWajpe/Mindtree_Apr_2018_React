import axios from 'axios';

export function increement(index){
    return{
        type:'INCREMENT_LIKES',
        index
    }
}

export function decreement(){
    return{
        type:'DECREMENT_LIKES'
    }
}

export function addComment(){
    return{
        type:'ADD_COMMENT'
    }
}



export function fetchPostsData(){
    console.log('Within fetchPostsData');
// make ajax request !  (axios)

var request = axios.get('https://api.myjson.com/bins/7ngi7');

return (dispatch)=>{
            request.then(
                (response)=>{
                        dispatch({type:'FETCH_POSTS',response:response.data})
                }
            )
}




}