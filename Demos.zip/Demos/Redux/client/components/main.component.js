
 import React from 'react';

    
 export default class MainComponent extends React.Component{
    
    componentDidMount(){
        this.props.fetchPostsData(); 
    }
    
    render(){ 

        // console.log(this.props);


         return <div>    
         {/* Dynamic Child to go here ! */}
         {React.cloneElement(this.props.children,this.props)}
                  </div>
     }
 }  