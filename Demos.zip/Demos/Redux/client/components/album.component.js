
 import React from 'react';
 import PostDetailComponent from './postdetails.component';
    
 export default class AlbumComponent extends React.Component{
     render(){        
         var postsToBeCreated = this.props.myposts.map(
            (p,i)=>{
                return <PostDetailComponent 
               {...this.props}
                post={p} key={p.id}
                 index={i} />
            }
        );
           return <div>
                            <h1 className="jumbotron" > All Posts </h1>
                             {postsToBeCreated}
                      </div>
     }
 }  