
 import React from 'react';
    import PostDetailsComponent from './postdetails.component';

 export default class PostComponent extends React.Component{
     render(){ 

            // fetch the code form URL
        var code = this.props.params.codeId;

      var index =  this.props.myposts.findIndex((p,i) => p.code == code)

        var currPost = this.props.myposts[index];

         return <div>

             <h1> Post  Component </h1>

            <PostDetailsComponent post={currPost}
             index={index} {...this.props} />

                  </div>
     }
 }  