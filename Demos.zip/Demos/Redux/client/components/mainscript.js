import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as allActions from '../actions/actionCreators';
import Main from './main.component';

// function mapStateToProps(storeData){

//         return{
//             myposts:storeData.posts,
//             mycomments:storeData.comments
//         }
// }

function mapStateToProps(storeData){

    return{
        myposts:storeData.posts,
        mycomments:storeData.comments
    }
}


function mapDispatchToProps(dispatch){
    return bindActionCreators(allActions,dispatch);
}

var app = connect(mapStateToProps,mapDispatchToProps)(Main);

export default app;