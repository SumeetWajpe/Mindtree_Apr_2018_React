
 import React from 'react';
 import {Link} from 'react-router';
    
 export default class PostDetailsComponent extends React.Component{
     render(){ 

           return  <div className="postStyle">
                            <div >
                                <Link to={`/post/${this.props.post.code}`}>
                                    <img src={this.props.post.display_src} 
                                height="100%" width="100%" />
                                </Link>
                            </div>
                            <div >
                                    <h3>{this.props.post.caption}</h3>
                                    <button className="btn btn-primary btn-lg" 
                                    onClick={this.props.increement.bind(this,this.props.index)}>
                                    <span className="glyphicon glyphicon-thumbs-up"></span>  
                                    &nbsp;    {this.props.post.likes}
                                        </button>
                            </div>
                        </div>               
     }
 }  