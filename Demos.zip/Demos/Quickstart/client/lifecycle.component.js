
 import React from 'react';
    import ReactDOM from 'react-dom';

 export default class LifeCycleComponent extends React.Component{
     
    
    constructor(props){
        super(props);
        console.log('Within Constructor !')
    }


    onChangeEventHandler(e){
                // updating the UI !
                // let txtInput = ReactDOM.findDOMNode(this.refs.txtCompanyName);
                this.setState({companyName: e.target.value });
    }

    componentWillMount(){
        /// set the initial state !
        this.state = {companyName:'Mindtree'};
        console.log('Within componentWillMount !')
    }

    componentDidMount(){
        // Access DOM , make AJAXified requests !
        console.log('Within componentDidMount !');        
    }
    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate !');
        
        if(arguments[1].companyName.length > 5){
            console.log(arguments[1].companyName);
            return false;
        }        
        return true;
    }
    componentWillUpdate(){
        console.log('Within componentWillUpdate !');          
    }
    componentDidUpdate(){
        console.log('Within componentDidUpdate !'); 
    }
    render(){ 
        console.log('Within render  !')        
         return <div>
                   Enter Company Name : 
                   <input ref="txtCompanyName" type="text" className="form-control"
                   onChange={this.onChangeEventHandler.bind(this)}
                   />
            <label>{this.state.companyName}</label>
             </div>
     }
 }  