// Code Here

import React from 'react';
import ReactDOM from 'react-dom';

import BasicComponent,{PI} from './basic.component';
import CourseComponent from './course.component'
     
import ListOfCourses from './ListOfCourses.component';
import ButtonListComponent from './buttonlist.component'

import LifeCycleComponent from './lifecycle.component'

import PostsComponent from './posts.component';


ReactDOM.render(<PostsComponent />,document.getElementById("content"))
