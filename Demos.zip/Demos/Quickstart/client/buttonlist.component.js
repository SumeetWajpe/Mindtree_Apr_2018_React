
 import React from 'react';
 import ReactDOM from 'react-dom';
import CustomButton from './custombutton.component'

 export default class ButtonListComponent extends React.Component{
     
    
    constructor(){
        super();
        this.state = {buttonlist: [10,20,30,40,50]}
    }

    addItemHandler(){
        // make change to array (state),
        // get the value from textbox !
        let inputValueFromUser = ReactDOM.findDOMNode(this.refs.txtInput);
        this.setState({buttonlist: [...this.state.buttonlist,+(inputValueFromUser.value)] })
    }
    render(){ 
        var buttonsToBeCreated = this.state.buttonlist.map(
            (b,index)=>{
                    return <CustomButton count={b} key={index * Math.random()} />
            }
        );
         return <div>
             <form>
            <input type="text" ref="txtInput"
                  className="form-control" /><button type="button" 
                 className="btn btn-success"
                 onClick={this.addItemHandler.bind(this)}
                 >Add </button>
                 </form>

                {buttonsToBeCreated}
             </div>
     }
 }  