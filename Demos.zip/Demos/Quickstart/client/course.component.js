
 import React from 'react';
    
export default class CourseComponent extends React.Component{
    render(){ 
        return <div>
                <h1> {this.props.coursedetails.title} </h1>  
                <b> Duration : </b> {this.props.coursedetails.duration} <br/>
                <b> Price : </b> {this.props.coursedetails.price} <br/>
                <hr/>
            </div>
    }
}  