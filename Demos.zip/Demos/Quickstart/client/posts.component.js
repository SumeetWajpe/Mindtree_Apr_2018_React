
 import React from 'react';
    import ReactDOM from 'react-dom';


    const styles = {backgroundColor:'orange',border:'2px solid red'};


 export default class PostsComponent extends React.Component{  
       componentWillMount(){
        this.state = {allposts:[],currPosts:[],isDisabled:true};

    }
    componentDidMount(){
        // make ajax request here !
        $.get('https://jsonplaceholder.typicode.com/posts',
        (response)=>{
                //console.log(response);
                this.setState({allposts: response});
        });             
    }  

    onChangeHandler(){
        let theInputValue = ReactDOM.findDOMNode(this.refs.txtPostId);      
        if(theInputValue.length != 0){
           this.setState({isDisabled : false})     
        }  
        else if(theInputValue.length == 0){
           this.setState({isDisabled : true})                 
        }
}
    addPostItemHandler(){
        let theInputValue = ReactDOM.findDOMNode(this.refs.txtPostId);      
        let thePost = this.state.allposts.find(p => p.id ==(theInputValue.value))      
        this.setState({currPosts:[...this.state.currPosts,thePost]});   
    }
    render(){ 
        var postsToBeCreated = this.state.currPosts.map(
            (p,i) =>{
                return <li key={p.id}> <b>{p.id} </b> .  {p.title} </li>
            }
        )
         return <div>
             <h1> Posts </h1>

Post Id :  <input type="text"
ref="txtPostId"
onChange={this.onChangeHandler.bind(this)}
 style={styles} />

 <input type="button"  value="Add" className="btn btn-primary" 
 onClick={this.addPostItemHandler.bind(this)}
 
 disabled={this.state.isDisabled}
 />


             <ul>
                 {postsToBeCreated}
                 </ul>
                </div>
     }
 }  