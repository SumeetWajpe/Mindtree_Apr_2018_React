
 import React from 'react';
    
 export default class CustomButtonComponent extends React.Component{
     
    constructor(props){
        super(props);
        this.state = {theCount:this.props.count}
    }

    ClickHandler(){
        
      this.setState({theCount: this.state.theCount + 1})
        
    }
    
    render(){ 
         return <div>
                <input type="button" 
                value={this.state.theCount}
                className="btn btn-primary"
                onClick={this.ClickHandler.bind(this)}
                />               
             </div>

     }
 }  