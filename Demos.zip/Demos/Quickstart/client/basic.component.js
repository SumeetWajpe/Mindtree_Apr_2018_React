 
 import React from 'react';

 //1. Create a component  (Class)
 //2. Instantiate a component (Object)

 export default class BasicComponent extends React.Component{
    render(){ 
        return <div>
                <h1 className="Header"> H1 as Component (JSX & ES6) ! </h1>
                      {/*  <h2> Sub Header </h2>  */}
            </div>
    }
}  

export const PI = 3.14;