
import React from 'react';
import CourseComponent from './course.component';

export default class ListOfCourses extends React.Component{

    constructor(){
        super();
    this.courses = [
        {title:'React',duration:'3 Days',price:5000},
        {title:'Node',duration:'3 Days',price:3000},
        {title:'Angular',duration:'4 Days',price:6000}        
    ];
}

    render(){

        var coursesToBeCreated = this.courses.map(
            (c)=>{
                    return <CourseComponent coursedetails={c}  />
            }
        );     

        return  <div>
                    {coursesToBeCreated}
        </div>

    }
}

/*


   <CourseComponent coursename={this.courses[0]}  />
        <CourseComponent coursename={this.courses[1]} />
        <CourseComponent coursename={this.courses[2]} />
*/