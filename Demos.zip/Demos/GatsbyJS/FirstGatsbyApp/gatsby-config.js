module.exports = {
  siteMetadata: {
    title: 'My Gatsby Default Starter',
  },
  plugins: ['gatsby-plugin-react-helmet'],
}
