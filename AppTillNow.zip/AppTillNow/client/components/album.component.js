
 import React from 'react';
    
 export default class AlbumComponent extends React.Component{
     render(){ 
         return <div>

             <h1> Album  Component </h1>
                  </div>
     }
 }  