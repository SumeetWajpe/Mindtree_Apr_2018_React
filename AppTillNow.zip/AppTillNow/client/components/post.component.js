
 import React from 'react';
    
 export default class PostComponent extends React.Component{
     render(){ 
         return <div>

             <h1> Post  Component </h1>
                  </div>
     }
 }  