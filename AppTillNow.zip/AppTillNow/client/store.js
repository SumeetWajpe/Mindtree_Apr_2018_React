import {createStore } from 'redux';

import rootReducer from './reducers/rootReducer'
import posts from './data/posts';
import comments from './data/comments';


var defStore = {posts,comments};

// createStore(reducers,DefaultData)
var store = createStore(rootReducer,defStore)


export default store;