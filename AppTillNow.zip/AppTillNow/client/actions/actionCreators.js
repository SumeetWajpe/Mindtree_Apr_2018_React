export default function increement(){
    return{
        type:'INCREMENT_LIKES'
    }
}