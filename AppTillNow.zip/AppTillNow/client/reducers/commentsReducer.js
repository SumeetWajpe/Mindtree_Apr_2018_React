export default function comments(defStore=[],action){
    switch(action.type){
        case 'ADD_COMMENT':
            console.log('Within Comments Reducer');
            console.log(action); 
            console.log(defStore);        
                   
            return defStore; // mutated Store !
            default:
            return defStore;
    }   
}