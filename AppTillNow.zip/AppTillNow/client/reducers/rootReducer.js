import {combineReducers} from 'redux';

import posts from './postsReducers';
import comments from './commentsReducer';

var rootReducer =combineReducers({posts,comments});
export default rootReducer;