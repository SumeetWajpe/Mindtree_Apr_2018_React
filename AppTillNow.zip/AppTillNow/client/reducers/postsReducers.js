export default function posts(defStore=[],action){
   
    switch(action.type){
        case 'INCREMENT_LIKES':
            console.log('Within Posts Reducer');
            console.log(action);        
            console.log(defStore);        
            
            return defStore; // mutated Store !
            default:
            return defStore;
    }   
    
}